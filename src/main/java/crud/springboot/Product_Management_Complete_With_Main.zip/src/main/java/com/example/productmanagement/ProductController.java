
package com.example.productmanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    private static String UPLOAD_DIR = System.getProperty("user.dir") + "/uploads";

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("products", productRepository.findAll());
        return "index";
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }

    @PostMapping("/addProduct")
    public String addProduct(@RequestParam("name") String name,
                             @RequestParam("price") double price,
                             @RequestParam("image") MultipartFile image) throws IOException {
        String imageFileName = image.getOriginalFilename();
        Path imagePath = Paths.get(UPLOAD_DIR, imageFileName);
        Files.write(imagePath, image.getBytes());

        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        product.setImage(imageFileName);

        productRepository.save(product);

        return "redirect:/";
    }
}
